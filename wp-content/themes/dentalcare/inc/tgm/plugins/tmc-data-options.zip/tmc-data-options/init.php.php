<?php
/*
Plugin Name:  TMC Data Options
Plugin URI: 
Description: Theme Options & Demo Data
Author: ThemeChampion
Author URI: https://themeforest.net/user/themechampion
Version: 2.0
Text Domain: 
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/
 require dirname( __FILE__ ) . '/extensions-init.php';
 require dirname( __FILE__ ) . '/options-config.php';